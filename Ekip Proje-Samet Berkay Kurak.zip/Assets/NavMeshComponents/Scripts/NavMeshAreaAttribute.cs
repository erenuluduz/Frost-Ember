using UnityEngine;

//***********************************************************************************
// Contributed by author jl-randazzo github.com/jl-randazzo
//***********************************************************************************
namespace NavMeshPlus.Extensions
{
    [System.Serializable]
    // See also NavMeshAreaAttributePropertyDrawer
    public class NavMeshAreaAttribute : PropertyAttribute
    {
    }
}
