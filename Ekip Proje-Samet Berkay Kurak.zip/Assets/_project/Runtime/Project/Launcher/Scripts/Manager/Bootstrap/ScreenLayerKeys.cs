namespace _project.Runtime.Project.Launcher.Scripts.Manager.Bootstrap
{
    public static class  ScreenLayerKeys
    {
        public const string FirstLayer = "FirstLayer";
    }
}