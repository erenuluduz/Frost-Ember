namespace _project.Runtime.Project.Launcher.Scripts.Manager.Bootstrap
{
    public static class ScreenKeys
    {
        public const string SettingsMenuScreen = "SettingsMenuScreen";
        public const string MainMenuScreen = "MainMenuScreen";
        public const string LevelSelectMenuScreen = "LevelSelectMenuScreen";
        public const string GameMenuScreen = "GameMenuScreen";


    }
}